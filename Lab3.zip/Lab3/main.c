#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <./inc/tm4c123gh6pm.h>
#include <inc/hw_memmap.h>
#include <inc/hw_types.h>
#include <driverlib/gpio.h>
#include <driverlib/pin_map.h>
#include <driverlib/sysctl.h>
#include <driverlib/uart.h>
#include <driverlib/interrupt.h>



#define led_g 0x08
#define led_r 0x02
#define led_b 0x04
#define led_cy 0x0C
#define led_y 0x0A
#define led_mag 0x06
#define led_white (led_r + led_g + led_b)


#define led_off 0x00
#define delay 1000

void separate_funct(void);
void printstring(char *str);
void UART0_Transmitter(unsigned char data);
void delayMs(int n);



volatile char cmnd_val[30] ;
volatile int cmnd_ind;
volatile int cmnd_cntrl;
volatile int blink_mode = 0;
int blink_rate = 1;


char full_cmnd[30];


struct cmnd
{
    char type[6];
    char data[6];
};

struct cmnd cmnd;

int colour_mode = 0;
int factor = 1;
int check =0;
int i =0,j=0;
int flag = 0;
int wait = 0;




int main(void)
{

    // GPIO setup
    SYSCTL_RCGC2_R |= 0x00000020;      // Activate clock for Port F

    GPIO_PORTF_LOCK_R = 0x4C4F434B;    // Unlock GPIO Port F
    GPIO_PORTF_CR_R = 0x1F;            // Allow changes to PF4-0
    GPIO_PORTF_AMSEL_R = 0x00;         // Disable analog on PF
    GPIO_PORTF_PCTL_R = 0x00000000;    // PCTL GPIO on PF4-0
    GPIO_PORTF_DIR_R = 0x0E;           // PF4, PF0 in, PF3-1 out
    GPIO_PORTF_AFSEL_R = 0x00;         // Disable alt funct on PF7-0
    GPIO_PORTF_PUR_R = 0x11;           // Enable pull-up on PF0 and PF4
    GPIO_PORTF_DEN_R = 0x1F;           // Enable digital I/O on PF4-0

    // Interrupt setup
    GPIO_PORTF_IS_R &= ~0x11;           // PF0 and PF4 edge-sensitive
    GPIO_PORTF_IBE_R &= ~0x11;          // PF0 and PF4 not both edges
    GPIO_PORTF_IEV_R &= ~0x11;          // PF0 and PF4 falling edge event
    GPIO_PORTF_ICR_R = 0x11;            // Clear flag4 and flag1
    GPIO_PORTF_IM_R |= 0x11;            // Arm interrupt on PF0 and PF4

    NVIC_PRI7_R = (NVIC_PRI7_R & 0xFF1FFFFF) | 0x00A00000;  // Priority 5
    NVIC_EN0_R = 0x40000000;             // Enable interrupt 30 in NVIC
    __asm("CPSIE I\n");                  //Interrupt enable using asm

    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);

    GPIOPinConfigure(GPIO_PA0_U0RX);
    GPIOPinConfigure(GPIO_PA1_U0TX);
    GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);

    UARTConfigSetExpClk(UART0_BASE, SysCtlClockGet(), 115200,(UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE | UART_CONFIG_PAR_NONE));
    printstring("Setup...\n\r\r");


     while(1)
    {
            // do nothing and wait for the interrupt to occur
        switch (colour_mode)
        {

            case 0: GPIO_PORTF_DATA_R = led_g;
                    break;

            case 1: GPIO_PORTF_DATA_R = led_b;
                    break;

            case 2: GPIO_PORTF_DATA_R = led_cy;
                    break;

            case 3: GPIO_PORTF_DATA_R = led_r;
                    break;

            case 4: GPIO_PORTF_DATA_R = led_y;
                    break;

            case 5: GPIO_PORTF_DATA_R = led_mag;
                    break;

            case 6: GPIO_PORTF_DATA_R = led_white;
                    break;


            default: break;




        }

        if (blink_mode == 0)
        {

        delayMs(delay/factor);
        if(!flag)
        {
            GPIO_PORTF_DATA_R = led_off;

        }
        delayMs(delay/factor);


        }

        else
        {   delayMs(blink_rate);
            if(!flag)
        {
            GPIO_PORTF_DATA_R = led_off;

        }
            delayMs(blink_rate);


        }

        if(cmnd_cntrl == 1)
        {
             cmnd_cntrl = 0;
             separate_funct();
         if(check == 1)
         {
         if((strcmp(cmnd.type, "color")==0))
         {
             switch(cmnd.data[0]) {
                                 case 'g':
                                     colour_mode = 0;
                                     break;
                                 case 'b':
                                     colour_mode = 1;
                                     break;
                                 case 'c':
                                     colour_mode = 2;
                                     break;
                                 case 'r':
                                     colour_mode = 3;
                                     break;
                                 case 'y':
                                     colour_mode = 4;
                                     break;
                                 case 'm':
                                     colour_mode = 5;
                                     break;
                                 case 'w':
                                     colour_mode = 6;
                                     break;
                                 default:
                                     break;
                             }

         }

        else if((strcmp(cmnd.type, "blink")==0))
         {
             blink_rate = atoi(cmnd.data);
             blink_rate = ((60000)/(2*blink_rate));
             blink_mode = 1;
         }
         }
        cmnd_val[0] = '\0';
        cmnd_ind = 0;
     }
    }
     return 0;
}

void UART0_Transmitter(unsigned char data)
{
    while((UART0_FR_R & (1<<5)) != 0); /* wait until Tx buffer not full */
    UART0_DR_R = data;                  /* before giving it another byte */
}

void printstring(char *str)
{
  while(*str)
    {
        UART0_Transmitter(*(str++));
    }
}


void separate_funct(void)
{
    int a = 0, b = 0;
    for(int i = 0; i<6; i++)
    {
        cmnd.data[i] = '\0';
        cmnd.type[i] = '\0';
    }
while((cmnd_val[a] != '\r'))
{
        if(!(((cmnd_val[a]>='A')&&(cmnd_val[a]<='Z')) || ((cmnd_val[a]>='a')&&(cmnd_val[a]<='z')) || ((cmnd_val[a]>='0')&&(cmnd_val[a]<='9'))))
            {
            a++;
            continue;
            }
        else
        {
            if((cmnd_val[a]>='A') && (cmnd_val[a]<='Z'))
                cmnd_val[a] = cmnd_val[a] + 32;
            full_cmnd[b] = cmnd_val[a];
            a++;
            b++;
        }
}
printstring("Request: ");
for(int i = 0; i<b; i++)
        UART0_Transmitter(full_cmnd[i]);
UART0_Transmitter('\n');
UART0_Transmitter('\r');
for(int i = 0; i<30; i++)
cmnd_val[i] = '\0';
for(int i = 0; i<5; i++)
cmnd.type[i] = full_cmnd[i];

printstring("Option: ");
for(int i = 0; i<5; i++)
    UART0_Transmitter(cmnd.type[i]);
UART0_Transmitter('\n');
UART0_Transmitter('\r');
printstring("Value: ");
for(int i = 0; i<(b-5); i++)
{
   cmnd.data[i] = full_cmnd[i+5];
   UART0_Transmitter(cmnd.data[i]);
}
UART0_Transmitter('\n');
UART0_Transmitter('\r');
if((strcmp(cmnd.type, "color")==0) || (strcmp(cmnd.type, "blink")==0))
{
    if((strcmp(cmnd.type, "color")==0))
    {
        if(!((strcmp(cmnd.data, "red")==0) ||(strcmp(cmnd.data, "white")==0) ||(strcmp(cmnd.data, "yellow")==0)\
         ||(strcmp(cmnd.data, "magenta")==0)||(strcmp(cmnd.data, "green")==0)||(strcmp(cmnd.data, "blue")==0)\
         ||(strcmp(cmnd.data, "cyan")==0)))
        {
           goto  label;
        }
    }
    else
    {
        for(int i = 0; i<(b-5); i++)
        {
           if(!((cmnd.data[i] >='0' )&& (cmnd.data[i] <='9')))
               goto label;
        }
    }
    printstring("Valid Entry\n\r");
    check= 1;
}
else
{
label: printstring("Sorry Invalid Entry!\n\r");
check =0;
return;
}

}


void GPIOF_Handler(void)
{
  if ((GPIO_PORTF_MIS_R & 0x10) == 0x10) /* check if interrupt causes by PF4/SW1*/
    {

      GPIO_PORTF_ICR_R  = 0x10; /* clear the interrupt flag */



      if(colour_mode==0)
      {
          colour_mode = 1;
      }
      else if(colour_mode == 1)
      {
          colour_mode = 2;
      }

      else if( colour_mode == 2)
      {
          colour_mode = 3;
      }

      else if(colour_mode== 3)
            {
               colour_mode = 4;
            }
      else if(colour_mode== 4)
            {
                 colour_mode = 5;

            }
      else if(colour_mode== 5)
            {
                colour_mode = 6;
            }
      else if(colour_mode== 6)
      {
          colour_mode=0;

      }


 }



 if ((GPIO_PORTF_MIS_R & 0x01) == 0x01) /* check if interrupt causes by PF0/SW2 */
    {    GPIO_PORTF_ICR_R = 0x01; /* clear the interrupt flag */
            blink_mode = 0;
            if(j==0)
              {
                  flag = 0;
                  factor = 2;
                  j=1;

              }
              else if(j == 1)
              {
                  factor = 4;
                  j=2;

              }

              else if( j== 2)
              {
                  factor = 8;
                  j=3;

              }

              else if( j== 3)
              {
                  factor = 16;
                  j=4;

              }

              else if( j== 4)
              {
                  factor = 32;
                  j=5;

              }

              else if( j== 5)
              {
                  factor = 1;
                  flag = 1;
                  j = 0;
              }


    }
}

void delayMs(int n)
{
int i, j;
for(i = 0 ; i < n; i++)
for(j = 0; j < 3180; j++)
{
    if(UARTCharsAvail(UART0_BASE))
                {
                    cmnd_val[cmnd_ind] = UARTCharGet(UART0_BASE);
                    if(cmnd_val[cmnd_ind] == '\b')
                    {
                        cmnd_val[cmnd_ind] = '\0';
                        cmnd_ind = cmnd_ind-1;
                        cmnd_val[cmnd_ind] = '\0';
                        UART0_Transmitter('\b');
                        UART0_Transmitter(' ');
                        UART0_Transmitter('\b');
                        cmnd_ind = cmnd_ind-1;
                    }
                    else
                    {
                    UART0_Transmitter(cmnd_val[cmnd_ind]);
                    }
                    if(cmnd_val[cmnd_ind]== '\r')
                        cmnd_cntrl = 1;
                    (cmnd_ind>30)? (cmnd_ind = 0): (cmnd_ind++);
                }
} /* do nothing for 1 ms */
}
