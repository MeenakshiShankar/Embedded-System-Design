#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <./inc/tm4c123gh6pm.h>
#include <inc/hw_memmap.h>
#include <inc/hw_types.h>
#include <driverlib/gpio.h>
#include <driverlib/pin_map.h>
#include <driverlib/sysctl.h>
#include <driverlib/uart.h>
#include <driverlib/interrupt.h>
void delayMs(int n);
volatile int result_new = 0;
volatile int temp_upd= 0;
volatile int adc_change = 0;


int count = 0;
int count2 = 0;
int count3 = 0;
int count4 = 0;

int pause_stat = 0;
int stop_stat = 0;
int stat_key_1 = 0;
int stat_key_2 = 0;

int set_dwn_flag = 0;
volatile unsigned long long int set_val = 0;


void separate_funct(void);
void printstring(char *str);
void UART0_Transmitter(unsigned char data);


volatile char cmnd_val[30] ;
volatile int cmnd_ind;
volatile int cmnd_cntrl;


struct cmnd
{
    char type[6];
    char data[6];
    //char funct[6];
};

struct cmnd cmnd;

char full_cmnd[30];


int check =0;
int data;
int flag = 0;
int user = 0;

void GPIO_init(void);
void LCD_init(void);
void lcd_data(unsigned char data);
void lcd_cmd(unsigned char cmd);
void lcd_write(char *str);

volatile unsigned long long int pre_tim = 0;

volatile unsigned long long int time_sec = 0;
volatile unsigned long long int m_sec = 0;
volatile unsigned long long int sec = 0;

//volatile unsigned long long int dwn_time_sec = 9;
volatile unsigned long long int dwn_msec = 0;
volatile unsigned long long int dwn_sec = 0;


volatile int start = 0, stop = 0 ;
long map(long x, long in_min, long in_max, long out_min, long out_max) {
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}
void SSD_init(void)
{
    SYSCTL_RCGC2_R |= 0x00000003;       // enable clock to GPIOA, GPIOB at clock gating control register
    // Enable the GPIO pins
    // For PORTB, all pins are used to set 7 segment display
    // For PORTA, pins 7 to 4 are used for selecting one of the four 7 segment display
    GPIO_PORTA_DIR_R |= 0xF0;       // PA4 to PA7 set to output
    GPIO_PORTB_DIR_R |= 0xFF;       // PB0 to PB7 set to output
   // GPIO_PORTC_DIR_R |= 0xF0;
    // enable the GPIO pins for digital function
    GPIO_PORTA_DEN_R |= 0xF0;       // enabling PA4 to PA7
    GPIO_PORTB_DEN_R |= 0xFF;       // enabling PB0 to PB8
   // GPIO_PORTC_DEN_R |= 0xF0;
}

volatile int digit  = 0;
int flag_upd = 0;
unsigned char digitPattern[] = {0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F};

int main(void)
{
//int i;
int x = 4999;
float temp;
int temp2;

SYSCTL_RCGC2_R |= 0x00000020;      // Activate clock for Port F

GPIO_PORTF_LOCK_R = 0x4C4F434B;    // Unlock GPIO Port F
GPIO_PORTF_CR_R = 0x1F;            // Allow changes to PF4-0
GPIO_PORTF_AMSEL_R = 0x00;         // Disable analog on PF
GPIO_PORTF_PCTL_R = 0x00000000;    // PCTL GPIO on PF4-0
GPIO_PORTF_DIR_R = 0x0E;           // PF4, PF0 in, PF3-1 out
GPIO_PORTF_AFSEL_R = 0x00;         // Disable alt funct on PF7-0
GPIO_PORTF_PUR_R = 0x11;           // Enable pull-up on PF0 and PF4
GPIO_PORTF_DEN_R = 0x1F;           // Enable digital I/O on PF4-0

// Interrupt setup for portf
GPIO_PORTF_IS_R &= ~0x11;           // PF0 and PF4 edge-sensitive
GPIO_PORTF_IBE_R &= ~0x11;          // PF0 and PF4 not both edges
GPIO_PORTF_IEV_R &= ~0x11;          // PF0 and PF4 falling edge event
GPIO_PORTF_ICR_R = 0x11;            // Clear flag4 and flag1
GPIO_PORTF_IM_R |= 0x11;            // Arm interrupt on PF0 and PF4
NVIC_PRI7_R = (NVIC_PRI7_R & 0xFF1FFFFF) | 0x00A00000;  // Priority 5
NVIC_EN0_R |= 0x40000000;             // Enable interrupt 30 in NVIC
__asm("CPSIE I\n");                  //Interrupt enable using asm
GPIO_PORTF_DATA_R = 0x00;



// Enable Peripheral Clocks
              SYSCTL_RCGCPWM_R |= 1;       // Enable clock to PWM0
              SYSCTL_RCGCGPIO_R |= 0x00000010;        // Enable clock at GPIOE (for ADC0)
              SYSCTL_RCC_R |= 0x001E0000;  // Enable divisor for PWM clock (clk/64)
              // Enable port PE5 for PWM0 M0PWM5
              GPIO_PORTE_AFSEL_R = 0x20;   // PE5 uses alternate function
              GPIO_PORTE_PCTL_R &= ~0x00F00000; // Make PE5 PWM output pin
              GPIO_PORTE_PCTL_R |= 0x00400000;  // Function 4 of pin PE5 -> M0PWM5
              GPIO_PORTE_DEN_R |= 0x20;    // Digital enable for PE5
              PWM0_2_CTL_R = 0;            // Stop counter
              PWM0_2_GENB_R = 0x0000008C;  // M0PWM5 output set when reload
                                           // Clear when match PWMCMPA
              PWM0_2_LOAD_R = 5000;        // Set load value for 50Hz : ((16MHz/64) / 50 Hz) = 5000
              PWM0_2_CMPA_R = 4400;        // set duty cycle to 180 degree for servo
              PWM0_2_CTL_R = 1;            // start timer
              PWM0_ENABLE_R = 0x20;        // Start PWM0 ch5
//
              SYSCTL_RCGCGPIO_R |= 0x01;
              GPIO_PORTA_DIR_R |= (1<<3)|(1<<2);
              GPIO_PORTA_DEN_R |= (1<<3)|(1<<2);
              GPIO_PORTA_DR8R_R |= (1<<2);

              GPIO_PORTA_DATA_R |= (1<<3);
              GPIO_PORTA_DATA_R &= ~(1<<2);
              GPIO_PORTA_DATA_R &= ~(1<<3);
              GPIO_PORTA_DATA_R |= (1<<2);



volatile int result;

SYSCTL_RCGCADC_R |= 0x00000001; /* enable clock to ADC0 */
SYSCTL_RCGCGPIO_R |= 0x10; /* enable clock to PE (AIN0 is on PE3) */



ADC0_ACTSS_R |= 0x00000008; /* enable ADC0 sequencer 3 */
ADC0_EMUX_R &= ~0xF000; /* software trigger conversion */
ADC0_SSMUX3_R = 0; /* get input from channel 0 */
/* initialize PE3 for AIN0 input */
GPIO_PORTE_AFSEL_R |= 8; /* enable alternate function */
GPIO_PORTE_DEN_R &= ~8; /* disable digital function */
GPIO_PORTE_AMSEL_R |= 8; /* enable analog function */
ADC0_SSCTL3_R |= 6; /* take one sample at a time, set flag at 1st sample */
ADC0_ACTSS_R |= 8; /* enable ADC0 sequencer 3 */



//NVIC_ST_CTRL_R = 0;            /* (1) disable SysTick during setup */
NVIC_ST_RELOAD_R = 1600000-1;
NVIC_ST_CTRL_R |= 7 ; // enable counter, interrupt and select system bus clock
NVIC_ST_CURRENT_R  = 0;



//timer setup
SYSCTL_RCGCTIMER_R |= 1<<1;
TIMER1_CTL_R &= (~(1<<0));
TIMER1_CFG_R = 0X4;
TIMER1_TAMR_R = 0X2;
TIMER1_TAPR_R |= 0XFF;
TIMER1_TAILR_R = 6250;
TIMER1_ICR_R |= 1<<0;
TIMER1_CTL_R |= 1<<0;
TIMER1_IMR_R |= 1<<0;
NVIC_EN0_R |= 0X200000; // INTERRUPT 21




SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);

GPIOPinConfigure(GPIO_PA0_U0RX);
GPIOPinConfigure(GPIO_PA1_U0TX);
GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);

UARTConfigSetExpClk(UART0_BASE, SysCtlClockGet(), 115200,(UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE | UART_CONFIG_PAR_NONE));
printstring("Setup...\n\r\r");


//GPIO_init();

//LCD_init();

SSD_init();

result = 0;

while(1) {

    if(cmnd_cntrl == 1)
    {
         cmnd_cntrl = 0;
         separate_funct();

         cmnd_val[0] = '\0';
         cmnd_ind = 0;
   }

ADC0_PSSI_R |= 8; /* start a conversion sequence 3 */
while((ADC0_RIS_R & 8) == 0)
{
 delayMs(1);
}/* wait for conversion complete */
result_new = ADC0_SSFIFO3_R; /* read conversion result */
ADC0_ISC_R = 8; /* clear completion flag */

temp_upd = result_new;

if(temp_upd > 4050)
{
    start = 1;
    stop = 0;
}


else if(temp_upd < 50)
{
    start = 0;
    stop = 1;
}

else
{
    start = 0;
    stop = 0;
}

if(abs(temp_upd - result) > 80)
{
    adc_change  = 1;
    TIMER1_TAILR_R =  map(result, 10,4050,62500,3125);
    pre_tim = time_sec;



}

if(time_sec-pre_tim >50)
{
    adc_change = 0;
}

delayMs(50);

if(UARTCharsAvail(UART0_BASE))
            {
                cmnd_val[cmnd_ind] = UARTCharGet(UART0_BASE);
                if(cmnd_val[cmnd_ind] == '\b')
                {
                    cmnd_val[cmnd_ind] = '\0';
                    cmnd_ind = cmnd_ind-1;
                    cmnd_val[cmnd_ind] = '\0';
                    UART0_Transmitter('\b');
                    UART0_Transmitter(' ');
                    UART0_Transmitter('\b');
                    cmnd_ind = cmnd_ind-1;
                }
                else
                {
                UART0_Transmitter(cmnd_val[cmnd_ind]);
                }
                if(cmnd_val[cmnd_ind]== '\r')
                    cmnd_cntrl = 1;
                (cmnd_ind>30)? (cmnd_ind = 0): (cmnd_ind++);
            }

temp=(((temp_upd)/4095.0)*4999.0);
temp2=(int)temp;
x=4999-temp2;
PWM0_2_CMPA_R=x;


 result = temp_upd;



}


}


void UART0_Transmitter(unsigned char data)
{
    while((UART0_FR_R & (1<<5)) != 0); /* wait until Tx buffer not full */
    UART0_DR_R = data;                  /* before giving it another byte */
}

void printstring(char *str)
{
  while(*str)
    {
        UART0_Transmitter(*(str++));
    }
}


void separate_funct(void)
{
    int a = 0, b = 0;
    for(int i = 0; i<6; i++)
    {
        cmnd.data[i] = '\0';
        cmnd.type[i] = '\0';
    }


while((cmnd_val[a] != '\r'))
{
        if(!(((cmnd_val[a]>='A')&&(cmnd_val[a]<='Z')) || ((cmnd_val[a]>='a')&&(cmnd_val[a]<='z')) || ((cmnd_val[a]>='0')&&(cmnd_val[a]<='9'))))
            {
            a++;
            continue;
            }
        else
        {
            if((cmnd_val[a]>='A') && (cmnd_val[a]<='Z'))
                cmnd_val[a] = cmnd_val[a] + 32;
            full_cmnd[b] = cmnd_val[a];
            a++;
            b++;
        }
}
printstring("Request: ");
for(int i = 0; i<b; i++)
    UART0_Transmitter(full_cmnd[i]);

UART0_Transmitter('\n');
UART0_Transmitter('\r');

for(int i = 0; i< 30;i++)
{
    if(i>=b)
    {
        full_cmnd[i]='\0';
    }
}

for(int i = 0; i<30; i++)
cmnd_val[i] = '\0';



if(b==6)
{
    for(int i = 0; i<6; i++)
    cmnd.type[i] = full_cmnd[i];

    printstring("Option: ");

    for(int i = 0; i<6; i++)
        UART0_Transmitter(cmnd.type[i]);
    UART0_Transmitter('\n');
    UART0_Transmitter('\r');
}

else
{for(int i = 0; i<5; i++)
cmnd.type[i] = full_cmnd[i];

printstring("Option: ");

for(int i = 0; i<5; i++)
    UART0_Transmitter(cmnd.type[i]);
UART0_Transmitter('\n');
UART0_Transmitter('\r');
}

printstring("Value: ");
for(int i = 0; i<(b-5); i++)
{
   cmnd.data[i] = full_cmnd[i+5];

   UART0_Transmitter(cmnd.data[i]);

}
UART0_Transmitter('\n');
UART0_Transmitter('\r');



if ((strcmp(cmnd.data, "stop")==0))
{   // GPIO_init();


    NVIC_ST_CTRL_R = 0;

    m_sec = 0;
    sec = 0;
    time_sec = 0;


    flag = 1;
    stop_stat = 1;
//    GPIO_PORTF_DATA_R &= 0;
//    GPIO_PORTF_DATA_R = 0x08;


    printstring("Stop");

    printstring("\n\r");


    printstring("Valid Entry\n\r");
    check= 1;



}


else if((strcmp(cmnd.type, "setto")==0))
{

    set_val = atoi(cmnd.data);

    m_sec = 0;
    sec = set_val;


    flag = 1;

    NVIC_ST_CTRL_R |= 7;

    set_dwn_flag = 1;

   // pause_stat = 1;

    printstring("Time Set");

    printstring("\n\r");


    printstring("Valid Entry\n\r");
    check= 1;

}



else if ((strcmp(cmnd.data, "start")==0))
{

    m_sec = 0;
    sec = 0;
    time_sec = 0;

    NVIC_ST_CTRL_R |= 7 ;


    stop_stat = 0;
    flag = 0;
    check= 1;



      printstring("Start");

      printstring("\n\r");

      printstring("Valid Entry\n\r");
      check= 1;
}


else if ((strcmp(cmnd.data, "pause")==0))
{
    NVIC_ST_CTRL_R = 0;

    pause_stat = 1;
    check= 1;
    flag = 1;



    printstring("Pause");
    printstring("\n\r");

    printstring("Valid Entry\n\r");
//    check= 1;



}

else if ((strcmp(cmnd.data, "resume")==0))
{
    NVIC_ST_CTRL_R |= 7;

    pause_stat = 0;
    flag = 0;
    check= 1;

    if(count4 == 0)
    {
        for(int i =0;i<50;i++){}
        GPIO_PORTA_DATA_R &= ~(0xF0);
        GPIO_PORTA_DATA_R |= 0x80;
        GPIO_PORTB_DATA_R = 0x00;
        //GPIO_PORTB_DATA_R = digitPattern[count3];

    }


    printstring("Resume");

    printstring("\n\r");

    printstring("Valid Entry\n\r");
    check= 1;
}



}



void GPIOF_Handler(void)
{



  if ((GPIO_PORTF_MIS_R & 0x10) == 0x10) /* check if interrupt causes by PF4/SW1*/
    {
        GPIO_PORTF_ICR_R  = 0x10; /* clear the interrupt flag */

     if((strcmp(cmnd.data, "stop")==0)||(stat_key_1 == 1))
     {

                                         stat_key_1 = 0;

                                         printstring("Stop\n\r");
                                         GPIO_PORTF_DATA_R &= 0;
                                         GPIO_PORTF_DATA_R = 0x02;

                                         m_sec = 0;
                                         sec = 0;
                                         time_sec = 0;


                                         NVIC_ST_CTRL_R = 0;



                                         flag = 1;
                                         stop_stat = 1;

                                         printstring("Valid Entry\n\r");
                                         check= 1;


     }
     else if((strcmp(cmnd.data, "start")==0)||(stat_key_1 == 0))
     {
                                         stat_key_1 = 1;
                                        printstring("Start\n\r");
                                        printstring("Valid Entry\n\r");
                                        GPIO_PORTF_DATA_R = 0x02;
                                            count = 0;
                                            count2 = 0;
                                            count3 = 0;
                                            count4 = 0;
                                            NVIC_ST_CTRL_R |= 7 ;
                                            stop_stat = 0;
                                            flag = 0;
                                            check= 1;


     }


    }


  if ((GPIO_PORTF_MIS_R & 0x01) == 0x01) /* check if interrupt causes by PF4/SW2*/
      {
          GPIO_PORTF_ICR_R  = 0x01; /* clear the interrupt flag */

       if((strcmp(cmnd.data, "pause")==0)||(stat_key_2 == 0))
       {

                                           stat_key_2 = 1;

                                           printstring("Pause \n\r");

                                           GPIO_PORTF_DATA_R &= 0x00;
                                           GPIO_PORTF_DATA_R |= 0x02;

                                           NVIC_ST_CTRL_R = 0;
                                           flag = 1;
                                           pause_stat = 1;


                                           printstring("Valid Entry\n\r");
                                           check= 1;


       }
       else if((strcmp(cmnd.data, "resume")==0)||(stat_key_2 == 1))
       {
                                          stat_key_2 = 0;
                                          printstring("Resume\n\r");
                                          printstring("Valid Entry\n\r");

                                              NVIC_ST_CTRL_R |= 7 ;
                                              pause_stat = 0;
                                              flag = 0;
                                              check= 1;


       }


      }








}


void delayMs(int n)
{
int i, j;
for(i = 0 ; i < n; i++)
for(j = 0; j < 15; j++)
{
    int result_new;
if(adc_change)
{
     result_new = temp_upd;
}
else{
    result_new  = sec*10+m_sec;
}
    for(int k=0;k<30;k++){}
     GPIO_PORTA_DATA_R &= ~(0xF0);
     GPIO_PORTB_DATA_R = 0;
     GPIO_PORTA_DATA_R = 0x10;
     digit = result_new%10;
     result_new = result_new/10;
     GPIO_PORTB_DATA_R = digitPattern[digit];

     for(int k =0;k<30;k++){}
     GPIO_PORTA_DATA_R &= ~(0xF0);
     GPIO_PORTB_DATA_R = 0;
     GPIO_PORTA_DATA_R = 0x20;
     digit = result_new%10;
     result_new = result_new/10;
     GPIO_PORTB_DATA_R = digitPattern[digit];

     for(int k =0;k<30;k++){}
     GPIO_PORTA_DATA_R &= ~(0xF0);
     GPIO_PORTB_DATA_R = 0;
     GPIO_PORTA_DATA_R = 0x40;
     digit = result_new%10;
     result_new = result_new/10;
     GPIO_PORTB_DATA_R = digitPattern[digit];


     for(int k =0;k<30;k++){}
     GPIO_PORTA_DATA_R &= ~(0xF0);
     GPIO_PORTB_DATA_R &= 0;
     GPIO_PORTA_DATA_R = 0x80;
     digit = result_new%10;
     result_new = result_new/10;
     GPIO_PORTB_DATA_R = digitPattern[digit];

}
}

void Timer1_Handler(void)
{
    if(start)
        GPIO_PORTF_DATA_R |= 1<<1;
    else if(stop)
        GPIO_PORTF_DATA_R &= ~(1<<1);
    else
        GPIO_PORTF_DATA_R ^= 1<<1;
    TIMER1_ICR_R  |= 1<<0;
}



void SysTick_Handler(void)
{


    if(set_dwn_flag == 0)

     {
         time_sec++;
         if(m_sec==9)
             {
                 sec++;
             }

         m_sec>8?(m_sec = 0 ):(m_sec++);


     }



    else if(set_dwn_flag == 1)
     {

        if(sec > 1)
        {
            sec--;
            delayMs(1000);
        }

        if(sec == 1)
             {
                 //m_sec++;
                 set_dwn_flag = 0;

             }




     }


   if((pause_stat == 1))
   {
       //GPIO_PORTF_DATA_R  ^= 0x02;
   }

   else
   {
       count = count+1;

       //GPIO_PORTF_DATA_R  ^= 0x02;  //toggle PF3 pin
   }

}
