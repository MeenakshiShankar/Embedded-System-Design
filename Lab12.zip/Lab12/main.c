#include <stdint.h>
#include "inc/tm4c123gh6pm.h"

#define led_g 0x08
#define led_r 0x02
#define led_b 0x04
#define led_cy 0x0C
#define led_y 0x0A
#define led_mag 0x06
#define led_white (led_r + led_g + led_b)

#define led_off 0x00
#define delay 1000

void led_blink(int wait);
void delayMs(int n);

int colour_mode = 0;
int factor = 1;

int i =0,j=0;
int flag = 0;
int wait = 0;

int main(void)
{

    SYSCTL_RCGC2_R |= 0x00000020;   /* Set bit5 of RCGCGPIO to enable clock to PORTF*/

     /* PORTF0 has special function, need to unlock to modify */
    GPIO_PORTF_LOCK_R = 0x4C4F434B;   /* unlock commit register */
    GPIO_PORTF_CR_R = 0x01;           /* make PORTF0 configurable */
    GPIO_PORTF_LOCK_R = 0;            /* lock commit register */


    /*Initialize PF3 as a digital output, PF0 and PF4 as digital input pins */

    GPIO_PORTF_DIR_R = ~(0x11);  /* Set PF4 and PF0 as a digital input pins */
    GPIO_PORTF_DIR_R = 0x0E;           /* Set PF3 as digital output to control green LED */
    GPIO_PORTF_DEN_R = 0x1F ;             /* make PORTF4-0 digital pins */
    GPIO_PORTF_PUR_R = 0x11;             /* enable pull up for PORTF4, 0 */

    /* configure PORTF4, 0 for falling edge trigger interrupt */
    GPIO_PORTF_IS_R  = ~(0x11);        /* make bit 4, 0 edge sensitive */
    GPIO_PORTF_IBE_R = ~(0x11);         /* trigger is controlled by IEV */
    GPIO_PORTF_IEV_R = ~(0x11);        /* falling edge trigger */
    GPIO_PORTF_ICR_R = (0x11);          /* clear any prior interrupt */
    GPIO_PORTF_IM_R  = (0x11);          /* unmask interrupt */

    /* enable interrupt in NVIC and set priority to 3 */
    NVIC_PRI7_R = 3 << 5;     /* set interrupt priority to 3 */
    NVIC_EN0_R = (1<<30);  /* enable IRQ30 (D30 of ISER[0]) */


    while(1)
    {
            // do nothing and wait for the interrupt to occur
        switch (colour_mode)
        {

            case 0: GPIO_PORTF_DATA_R = led_g;
                    break;

            case 1: GPIO_PORTF_DATA_R = led_b;
                    break;

            case 2: GPIO_PORTF_DATA_R = led_cy;
                    break;

            case 3: GPIO_PORTF_DATA_R = led_r;
                    break;

            case 4: GPIO_PORTF_DATA_R = led_y;
                    break;

            case 5: GPIO_PORTF_DATA_R = led_mag;
                    break;

            case 6: GPIO_PORTF_DATA_R = led_white;
                    break;


            default: break;




        }

        delayMs(delay/factor);
        if(!flag)
        {
            GPIO_PORTF_DATA_R = led_off;

        }
        delayMs(delay/factor);





    }
}

/* SW1 is connected to PF4 pin, SW2 is connected to PF0. */
/* Both of them trigger PORTF falling edge interrupt */
void GPIOF_Handler(void)
{
  if ((GPIO_PORTF_MIS_R & 0x10) == 0x10) /* check if interrupt causes by PF4/SW1*/
    {

      GPIO_PORTF_ICR_R  = 0x10; /* clear the interrupt flag */



      if(colour_mode==0)
      {
          colour_mode = 1;
      }
      else if(colour_mode == 1)
      {
          colour_mode = 2;
      }

      else if( colour_mode == 2)
      {
          colour_mode = 3;
      }

      else if(colour_mode== 3)
            {
               colour_mode = 4;
            }
      else if(colour_mode== 4)
            {
                 colour_mode = 5;

            }
      else if(colour_mode== 5)
            {
                colour_mode = 6;
            }
      else if(colour_mode== 6)
      {
          colour_mode=0;

      }


 }



 if ((GPIO_PORTF_MIS_R & 0x01) == 0x01) /* check if interrupt causes by PF0/SW2 */
    {    GPIO_PORTF_ICR_R = 0x01; /* clear the interrupt flag */

            if(j==0)
              {
                  flag = 0;
                  factor = 2;
                  j=1;

              }
              else if(j == 1)
              {
                  factor = 4;
                  j=2;

              }

              else if( j== 2)
              {
                  factor = 8;
                  j=3;

              }

              else if( j== 3)
              {
                  factor = 16;
                  j=4;

              }

              else if( j== 4)
              {
                  factor = 32;
                  j=5;

              }

              else if( j== 5)
              {
                  factor = 1;
                  flag = 1;
                  j = 0;
              }


    }
}

a


void delayMs(int n)
{
int i, j;
for(i = 0 ; i < n; i++)
for(j = 0; j < 3180; j++) {} /* do nothing for 1 ms */
}
