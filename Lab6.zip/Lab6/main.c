#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <./inc/tm4c123gh6pm.h>
#include <inc/hw_memmap.h>
#include <inc/hw_types.h>
#include <driverlib/gpio.h>
#include <driverlib/pin_map.h>
#include <driverlib/sysctl.h>
#include <driverlib/uart.h>
#include <driverlib/interrupt.h>

#ifndef GPIO_H_
#include"GPIO.h"
#endif

#ifndef KEYPAD_H_
#include"keypad.h"
#endif

void GPIO_init(void);
void LCD_init(void);
void lcd_data(unsigned char data);
void lcd_cmd(unsigned char cmd);
void lcd_write(char *str);
void delayMs(int n);

unsigned char digitPattern[] = {0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F};
int count = 0;
int count2 = 0;
int count3 = 0;
int count4 = 0;

int check =0;
char data;
int flag = 0;




void SSD_init(void)
{
    SYSCTL_RCGC2_R |= 0x00000003;       // enable clock to GPIOA, GPIOB at clock gating control register
    // Enable the GPIO pins
    // For PORTB, all pins are used to set 7 segment display
    // For PORTA, pins 7 to 4 are used for selecting one of the four 7 segment display
    GPIO_PORTA_DIR_R |= 0xF0;       // PA4 to PA7 set to output
    GPIO_PORTB_DIR_R |= 0xFF;       // PB0 to PB7 set to output
   // GPIO_PORTC_DIR_R |= 0xF0;
    // enable the GPIO pins for digital function
    GPIO_PORTA_DEN_R |= 0xF0;       // enabling PA4 to PA7
    GPIO_PORTB_DEN_R |= 0xFF;       // enabling PB0 to PB8
   // GPIO_PORTC_DEN_R |= 0xF0;
}

void separate_funct(void);
void printstring(char *str);
void UART0_Transmitter(unsigned char data);



volatile char cmnd_val[30] ;
volatile int cmnd_ind;
volatile int cmnd_cntrl;


struct cmnd
{
    char type[6];
    char data[6];
    //char funct[6];
};

struct cmnd cmnd;

char full_cmnd[30];


int temp = 0;
int pause_stat = 0;
int stop_stat = 0;
int stat_key_1 = 0;
int stat_key_2 = 0;


int main()
{
    SYSCTL_RCGC2_R |= 0x00000020;      // Activate clock for Port F

    GPIO_PORTF_LOCK_R = 0x4C4F434B;    // Unlock GPIO Port F
    GPIO_PORTF_CR_R = 0x1F;            // Allow changes to PF4-0
    GPIO_PORTF_AMSEL_R = 0x00;         // Disable analog on PF
    GPIO_PORTF_PCTL_R = 0x00000000;    // PCTL GPIO on PF4-0
    GPIO_PORTF_DIR_R = 0x0E;           // PF4, PF0 in, PF3-1 out
    GPIO_PORTF_AFSEL_R = 0x00;         // Disable alt funct on PF7-0
    GPIO_PORTF_PUR_R = 0x11;           // Enable pull-up on PF0 and PF4
    GPIO_PORTF_DEN_R = 0x1F;           // Enable digital I/O on PF4-0

    // Interrupt setup
    GPIO_PORTF_IS_R &= ~0x11;           // PF0 and PF4 edge-sensitive
    GPIO_PORTF_IBE_R &= ~0x11;          // PF0 and PF4 not both edges
    GPIO_PORTF_IEV_R &= ~0x11;          // PF0 and PF4 falling edge event
    GPIO_PORTF_ICR_R = 0x11;            // Clear flag4 and flag1
    GPIO_PORTF_IM_R |= 0x11;            // Arm interrupt on PF0 and PF4

    NVIC_PRI7_R = (NVIC_PRI7_R & 0xFF1FFFFF) | 0x00A00000;  // Priority 5
    NVIC_EN0_R = 0x40000000;             // Enable interrupt 30 in NVIC
    __asm("CPSIE I\n");                  //Interrupt enable using asm

    //NVIC_ST_CTRL_R = 0;            /* (1) disable SysTick during setup */
    NVIC_ST_RELOAD_R = 1000000-1; // one second delay reload value
    NVIC_ST_CTRL_R |= 7 ; // enable counter, interrupt and select system bus clock
    NVIC_ST_CURRENT_R  = 0;

    SSD_init();


    keypad_init();


    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);

    GPIOPinConfigure(GPIO_PA0_U0RX);
    GPIOPinConfigure(GPIO_PA1_U0TX);
    GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);

    UARTConfigSetExpClk(UART0_BASE, SysCtlClockGet(), 115200,(UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE | UART_CONFIG_PAR_NONE));
    printstring("Setup...\n\r\r");

    GPIO_init();

    LCD_init();
    lcd_cmd(0x80);
    lcd_write("Welcome");
    lcd_cmd(0xC0);
    lcd_write("DESE ");

    while (1)
    {
        //do nothing here



                if(cmnd_cntrl == 1)
                {
                     cmnd_cntrl = 0;
                     separate_funct();

                     cmnd_val[0] = '\0';
                     cmnd_ind = 0;
               }



       if(count4 == 0)

       { for(int i =0;i<60;i++){}

        GPIO_PORTA_DATA_R &= ~(0xF0);
        GPIO_PORTA_DATA_R |= 0x10;
        GPIO_PORTB_DATA_R = 0;
        GPIO_PORTB_DATA_R = digitPattern[count];

        for(int i =0;i<60;i++){}
        GPIO_PORTA_DATA_R &= ~(0xF0);
        GPIO_PORTA_DATA_R |= 0x20;
        GPIO_PORTB_DATA_R = 0;
        GPIO_PORTB_DATA_R = digitPattern[count2];

        for(int i =0;i<60;i++){}
        GPIO_PORTA_DATA_R &= ~(0xF0);
        GPIO_PORTA_DATA_R |= 0x40;
        GPIO_PORTB_DATA_R = 0;
        GPIO_PORTB_DATA_R = digitPattern[count3];
       }

       else
       {
           for(int i =0;i<60;i++){}

            GPIO_PORTA_DATA_R &= ~(0xF0);
            GPIO_PORTA_DATA_R |= 0x10;
            GPIO_PORTB_DATA_R = 0;
            GPIO_PORTB_DATA_R = digitPattern[count];

            for(int i =0;i<60;i++){}
            GPIO_PORTA_DATA_R &= ~(0xF0);
            GPIO_PORTA_DATA_R |= 0x20;
            GPIO_PORTB_DATA_R = 0;
            GPIO_PORTB_DATA_R = digitPattern[count2];

            for(int i =0;i<60;i++){}
            GPIO_PORTA_DATA_R &= ~(0xF0);
            GPIO_PORTA_DATA_R |= 0x40;
            GPIO_PORTB_DATA_R = 0;
            GPIO_PORTB_DATA_R = digitPattern[count3];


            for(int i =0;i<60;i++){}
            GPIO_PORTA_DATA_R &= ~(0xF0);
            GPIO_PORTA_DATA_R |= 0x80;
            GPIO_PORTB_DATA_R = 0;
            GPIO_PORTB_DATA_R = digitPattern[count4];


       }

//       for(int i =0;i<10;i++){}
//       GPIO_PORTF_DATA_R = 0x04;
//       for(int i =0;i<60;i++){}
//       GPIO_PORTF_DATA_R = 0x00;

        if (count == 10)
        {
            count = 0;
            for(int i =0;i<20;i++){}
            GPIO_PORTA_DATA_R &= ~(0xF0);
            GPIO_PORTA_DATA_R |= 0x20;
            GPIO_PORTB_DATA_R = 0;
            GPIO_PORTB_DATA_R = digitPattern[count];
            count2 = count2 + 1;
        }

        if (count2 == 10)
        {
            count2 = 0;
            for(int i =0;i<20;i++){}
            GPIO_PORTA_DATA_R &= ~(0xF0);
            GPIO_PORTA_DATA_R |= 0x20;
            GPIO_PORTB_DATA_R = 0;
            GPIO_PORTB_DATA_R = digitPattern[count2];
            count3 = count3 + 1;
        }

        if (count3 == 10)
        {
            count3 = 0;
            for(int i =0;i<20;i++){}
            GPIO_PORTA_DATA_R &= ~(0xF0);
            GPIO_PORTA_DATA_R |= 0x20;
            GPIO_PORTB_DATA_R = 0;
            GPIO_PORTB_DATA_R = digitPattern[count3];
            count4 = count4 + 1;
        }

        if(count4 == 10)
        {
           count4 = 0;
           for(int i =0;i<20;i++){}
           GPIO_PORTA_DATA_R &= ~(0xF0);
           GPIO_PORTA_DATA_R |= 0x20;
           GPIO_PORTB_DATA_R = 0;
           GPIO_PORTB_DATA_R = digitPattern[count4];
        }


        if(UARTCharsAvail(UART0_BASE))
                    {
                        cmnd_val[cmnd_ind] = UARTCharGet(UART0_BASE);
                        if(cmnd_val[cmnd_ind] == '\b')
                        {
                            cmnd_val[cmnd_ind] = '\0';
                            cmnd_ind = cmnd_ind-1;
                            cmnd_val[cmnd_ind] = '\0';
                            UART0_Transmitter('\b');
                            UART0_Transmitter(' ');
                            UART0_Transmitter('\b');
                            cmnd_ind = cmnd_ind-1;
                        }
                        else
                        {
                        UART0_Transmitter(cmnd_val[cmnd_ind]);
                        }
                        if(cmnd_val[cmnd_ind]== '\r')
                            cmnd_cntrl = 1;
                        (cmnd_ind>30)? (cmnd_ind = 0): (cmnd_ind++);
                    }


    }

//    if (stop_stat == 1)
//    {
//        GPIO_PORTF_DATA_R = 0x08;
//    }
}

void UART0_Transmitter(unsigned char data)
{
    while((UART0_FR_R & (1<<5)) != 0); /* wait until Tx buffer not full */
    UART0_DR_R = data;                  /* before giving it another byte */
}

void printstring(char *str)
{
  while(*str)
    {
        UART0_Transmitter(*(str++));
    }
}


void separate_funct(void)
{
    int a = 0, b = 0;
    for(int i = 0; i<6; i++)
    {
        cmnd.data[i] = '\0';
        cmnd.type[i] = '\0';
    }


while((cmnd_val[a] != '\r'))
{
        if(!(((cmnd_val[a]>='A')&&(cmnd_val[a]<='Z')) || ((cmnd_val[a]>='a')&&(cmnd_val[a]<='z')) || ((cmnd_val[a]>='0')&&(cmnd_val[a]<='9'))))
            {
            a++;
            continue;
            }
        else
        {
            if((cmnd_val[a]>='A') && (cmnd_val[a]<='Z'))
                cmnd_val[a] = cmnd_val[a] + 32;
            full_cmnd[b] = cmnd_val[a];
            a++;
            b++;
        }
}
printstring("Request: ");
for(int i = 0; i<b; i++)
    UART0_Transmitter(full_cmnd[i]);

UART0_Transmitter('\n');
UART0_Transmitter('\r');

for(int i = 0; i< 30;i++)
{
    if(i>=b)
    {
        full_cmnd[i]='\0';
    }
}

for(int i = 0; i<30; i++)
cmnd_val[i] = '\0';



if(b==6)
{
    for(int i = 0; i<6; i++)
    cmnd.type[i] = full_cmnd[i];

    printstring("Option: ");

    for(int i = 0; i<6; i++)
        UART0_Transmitter(cmnd.type[i]);
    UART0_Transmitter('\n');
    UART0_Transmitter('\r');
}

else
{for(int i = 0; i<5; i++)
cmnd.type[i] = full_cmnd[i];

printstring("Option: ");

for(int i = 0; i<5; i++)
    UART0_Transmitter(cmnd.type[i]);
UART0_Transmitter('\n');
UART0_Transmitter('\r');
}

printstring("Value: ");
for(int i = 0; i<(b-5); i++)
{
   cmnd.data[i] = full_cmnd[i+5];
   UART0_Transmitter(cmnd.data[i]);
}
UART0_Transmitter('\n');
UART0_Transmitter('\r');



if ((strcmp(cmnd.data, "stop")==0))
{   // GPIO_init();

    LCD_init();
    count = 0;
    count2 = 0;
    count3 = 0;
    count4 = 0;




    NVIC_ST_CTRL_R = 0;
    flag = 1;
    stop_stat = 1;
    GPIO_PORTF_DATA_R = 0x08;

    lcd_cmd(0x01);
    lcd_cmd(0x02);
    lcd_cmd(0x80);
    lcd_write("Timer   ");
    lcd_cmd(0xC0);
    lcd_write("Ready   ");

    printstring("Stop");

    printstring("\n\r");


    printstring("Valid Entry\n\r");
    check= 1;



}

else if ((strcmp(cmnd.data, "start")==0))
{
    count = 0;
    count2 = 0;
    count3 = 0;
    count4 = 0;
    NVIC_ST_CTRL_R |= 7 ;

    stop_stat = 0;
    flag = 0;
    check= 1;

    lcd_cmd(0x01);
    lcd_cmd(0x02);
    lcd_cmd(0x80);
    lcd_write("Timer   ");
    lcd_cmd(0xC0);
    lcd_write("Running   ");

      printstring("Start");

      printstring("\n\r");

      printstring("Valid Entry\n\r");
      check= 1;
}


else if ((strcmp(cmnd.data, "pause")==0))
{
    NVIC_ST_CTRL_R |= 7;
    //GPIO_PORTF_DATA_R = 0x04;
    pause_stat = 1;
    check= 1;
    flag = 1;

    lcd_cmd(0x01);
    lcd_cmd(0x02);
    lcd_cmd(0x80);
    lcd_write("Timer   ");
    lcd_cmd(0xC0);
    lcd_write("Paused   ");


    printstring("Pause");
    printstring("\n\r");

    printstring("Valid Entry\n\r");
    check= 1;



}

else if ((strcmp(cmnd.data, "resume")==0))
{
    NVIC_ST_CTRL_R |= 7;
    //GPIO_PORTF_DATA_R = 0x08;
    pause_stat = 0;
    flag = 0;
    check= 1;

    if(count4 == 0)
    {
        for(int i =0;i<50;i++){}
        GPIO_PORTA_DATA_R &= ~(0xF0);
        GPIO_PORTA_DATA_R |= 0x80;
        GPIO_PORTB_DATA_R = 0x00;
        //GPIO_PORTB_DATA_R = digitPattern[count3];

    }


    lcd_cmd(0x01);
    lcd_cmd(0x02);
    lcd_cmd(0x80);
    lcd_write("Timer   ");
    lcd_cmd(0xC0);
    lcd_write("Running   ");



    printstring("Resume");

    printstring("\n\r");

    printstring("Valid Entry\n\r");
    check= 1;
}

//else
//{
//label: printstring("Sorry Invalid Entry!\n\r");
//check =0;
//return;
//}

}


void GPIOF_Handler(void)
{



  if ((GPIO_PORTF_MIS_R & 0x10) == 0x10) /* check if interrupt causes by PF4/SW1*/
    {
        GPIO_PORTF_ICR_R  = 0x10; /* clear the interrupt flag */

     if((strcmp(cmnd.data, "stop")==0)||(stat_key_1 == 1))
     {

                                         stat_key_1 = 0;

                                         printstring("Stop\n\r");
                                         GPIO_PORTF_DATA_R = 0x08;
                                         count = 0;
                                             count2 = 0;
                                             count3 = 0;
                                             count4 = 0;

                                         NVIC_ST_CTRL_R = 0;
                                         flag = 1;
                                         stop_stat = 1;


                                         lcd_cmd(0x01);
                                         lcd_cmd(0x02);
                                         lcd_cmd(0x80);
                                         lcd_write("Timer  ");
                                         lcd_cmd(0xC0);
                                         lcd_write("Ready   ");

                                         printstring("Valid Entry\n\r");
                                         check= 1;


     }
     else if((strcmp(cmnd.data, "start")==0)||(stat_key_1 == 0))
     {
                                         stat_key_1 = 1;
                                        printstring("Start\n\r");
                                        //GPIO_PORTF_DATA_R = 0x08;
                                        count = 0;
                                            count2 = 0;
                                            count3 = 0;
                                            count4 = 0;
                                            NVIC_ST_CTRL_R |= 7 ;
                                            stop_stat = 0;
                                            flag = 0;
                                            check= 1;
                                            lcd_cmd(0x01);
                                            lcd_cmd(0x02);
                                            lcd_cmd(0x80);
                                            lcd_write("Timer   ");
                                            lcd_cmd(0xC0);
                                            lcd_write("Running   ");

     }


    }


  if ((GPIO_PORTF_MIS_R & 0x01) == 0x01) /* check if interrupt causes by PF4/SW1*/
      {
          GPIO_PORTF_ICR_R  = 0x01; /* clear the interrupt flag */

       if((strcmp(cmnd.data, "pause")==0)||(stat_key_2 == 0))
       {

                                           stat_key_2 = 1;

                                           printstring("Pause \n\r");



                                           NVIC_ST_CTRL_R |= 7;
                                           flag = 1;
                                           pause_stat = 1;


                                           lcd_cmd(0x01);
                                           lcd_cmd(0x02);
                                           lcd_cmd(0x80);
                                           lcd_write("Timer   ");
                                           lcd_cmd(0xC0);
                                           lcd_write("Paused   ");

                                           printstring("Valid Entry\n\r");
                                           check= 1;


       }
       else if((strcmp(cmnd.data, "resume")==0)||(stat_key_2 == 1))
       {
                                          stat_key_2 = 0;
                                          printstring("Resume\n\r");
                                          GPIO_PORTF_DATA_R = 0x08;



                                              NVIC_ST_CTRL_R |= 7 ;
                                              pause_stat = 0;
                                              flag = 0;
                                              check= 1;
                                              lcd_cmd(0x01);
                                              lcd_cmd(0x02);
                                              lcd_cmd(0x80);
                                              lcd_write("Timer   ");
                                              lcd_cmd(0xC0);
                                              lcd_write("Running   ");

       }


      }








}


void lcd_data(unsigned char data)
{
    GPIO_PORTB_DATA_R = data;
    GPIO_PORTA_DATA_R |= 0x60;
    GPIO_PORTA_DATA_R &= ~0x80;
    delayMs(2);
    GPIO_PORTA_DATA_R |= 0x80;
}

void lcd_cmd(unsigned char cmd)
{
    GPIO_PORTB_DATA_R = cmd;
    GPIO_PORTA_DATA_R &= ~0x60;
    GPIO_PORTA_DATA_R &= ~0x80;
    delayMs(2);
    GPIO_PORTA_DATA_R |= 0x80;
}

void lcd_write(char *str)
{
    /* Writing a string to LCD */
    int length=strlen(str);
    for(int i=0;i<length && i<16;i++)
        lcd_data(str[i]);
}




void GPIO_init(void)
{
            SYSCTL_RCGC2_R |= 0x23;
            GPIO_PORTA_CR_R = 0xC0;         // make PORT A6, A7 configurable
            GPIO_PORTB_CR_R = 0xFF;         // make PORTB configurable
            GPIO_PORTA_DEN_R = 0xC0;
            GPIO_PORTA_DIR_R = 0xC0;
            GPIO_PORTB_DEN_R = 0xFF;
            GPIO_PORTB_DIR_R = 0xFF;

            GPIO_PORTA_DEN_R |= 0xF0;
            GPIO_PORTA_DIR_R |= 0xF0;

            GPIO_PORTF_LOCK_R = 0x4C4F434B;    // Unlock GPIO Port F
            GPIO_PORTF_CR_R = 0x1F;            // Allow changes to PF4-0
            GPIO_PORTF_AMSEL_R = 0x00;         // Disable analog on PF
            GPIO_PORTF_PCTL_R = 0x00000000;    // PCTL GPIO on PF4-0
            GPIO_PORTF_DIR_R = 0x0E;           // PF4, PF0 in, PF3-1 out
            GPIO_PORTF_AFSEL_R = 0x00;         // Disable alt funct on PF7-0
            GPIO_PORTF_PUR_R = 0x11;           // Enable pull-up on PF0 and PF4
            GPIO_PORTF_DEN_R = 0x1F;           // Enable digital I/O on PF4-0

            // Interrupt setup
            GPIO_PORTF_IS_R &= ~0x11;           // PF0 and PF4 edge-sensitive
            GPIO_PORTF_IBE_R &= ~0x11;          // PF0 and PF4 not both edges
            GPIO_PORTF_IEV_R &= ~0x11;          // PF0 and PF4 falling edge event
            GPIO_PORTF_ICR_R = 0x11;            // Clear flag4 and flag1
            GPIO_PORTF_IM_R |= 0x11;            // Arm interrupt on PF0 and PF4

            NVIC_PRI7_R = (NVIC_PRI7_R & 0xFF1FFFFF) | 0x00A00000;  // Priority 5
            NVIC_EN0_R = 0x40000000;             // Enable interrupt 30 in NVIC
            __asm("CPSIE I\n");                  //Interrupt enable using asm
                    //Interrupt enable using asm

     SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
     SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);

     GPIOPinConfigure(GPIO_PA0_U0RX);
     GPIOPinConfigure(GPIO_PA1_U0TX);
     GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);

     UARTConfigSetExpClk(UART0_BASE, SysCtlClockGet(), 115200,(UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE | UART_CONFIG_PAR_NONE));
     printstring("Setup...\n\r\r");

}




void LCD_init(void)
{
    lcd_cmd(0x38);
    lcd_cmd(0x06);
    lcd_cmd(0x0C);
    lcd_cmd(0x01);
    delayMs(10);
}






// this routine will execute after every one second

void SysTick_Handler(void)
{

   if((pause_stat == 1))
   {

       GPIO_PORTF_DATA_R  ^= 0x04;
   }

   else
   {
       count = count+1;

       GPIO_PORTF_DATA_R  ^= 0x08;  //toggle PF3 pin
   }

}


void delayMs(int n)
{
int i, j;
for(i = 0 ; i < n; i++)
for(j = 0; j < 3180; j++)
{

} /* do nothing for 1 ms */
}
