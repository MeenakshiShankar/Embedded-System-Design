#ifndef ALLFUNCDEF_H_
#define ALLFUNCDEF_H_


// list of functions
void GPIO_init(void);
void LCD_init(void);
void welcome_msg(void);
void delay(int n);                   // n milisecond
void lcd_data(unsigned char data);
void lcd_cmd(unsigned char cmd);
void lcd_write(char *str);
void GPIOPortF_Handler(void);
void Clear_memory(void);





#endif /* ALLFUNCDEF_H_ */
